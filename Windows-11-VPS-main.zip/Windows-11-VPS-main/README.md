## Windows 11 RDP - by fb.com/thuong.hai.581

Here this tutorial using Azure Cloud Shell to create Virtual Machine on Microsoft Learn Sandbox. <br><br>
😎 It's Two Hours RDP Completely Free.

## NEW VERSION RELEASE (Win2022/Win10/Win11): 

- *Open This : https://docs.microsoft.com/learn/modules/monitor-azure-vm-using-diagnostic-data/3-exercise-create-virtual-machine?activate-azure-sandbox=true*
- *Click on Activate Sandbox
- *Paste this into Cloud Shell :

-   ```console  
    curl -skLO is.gd/azurewinvmplus ; chmod +x azurewinvmplus ; ./azurewinvmplus 
    ```

![image](https://user-images.githubusercontent.com/58414694/185373362-727add31-c695-41e2-a93e-16ac4a76d4ae.png)


### Using Method (Win11-ONLY):


- Open This : https://docs.microsoft.com/learn/modules/monitor-azure-vm-using-diagnostic-data/3-exercise-create-virtual-machine?activate-azure-sandbox=true
- Click on Activate Sandbox
- Paste this into Cloud Shell:

-  ```console 
    curl -skLO is.gd/azurewin11vm ; chmod +x azurewin11vm ; ./azurewin11vm    
    ```
- *Enjoy!!*



Location: Your choice

Username: `azureuser`

Password: `WindowsPassword@001`


![image](https://user-images.githubusercontent.com/58414694/148490063-3657aeb5-541f-4e27-88a2-735ad990df0e.png)

- Wait for it to setup the Windows 11 machine

- After it's done, it will give you the IP address of the RDP.

- Open your preferred Remote Desktop client, type the IP adress and use the credentials provided.


### WARN

THIS IS ONLY FOR EDUCATIONAL PURPOSES

DON'T USE FOR MINING OR ILLEGAL USE

---

### OPTIONAL:

1H: https://docs.microsoft.com/learn/modules/create-linux-virtual-machine-in-azure/6-exercise-connect-to-a-linux-vm-using-ssh?activate-azure-sandbox=true

1H: https://docs.microsoft.com/learn/modules/build-a-web-app-with-mean-on-a-linux-vm/3-create-a-vm?activate-azure-sandbox=true

FAQ: Script stuck at "checking"...? Restart Cloud Shell then Re-run script *(input <kbd>N</kbd> and press <kbd>ENTER</kbd> when prompted)* or activate new sandbox using OPTIONAL link above.

#### Main Repository: https://github.com/kmille36/Windows-11-VPS
